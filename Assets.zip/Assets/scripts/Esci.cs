using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Esci : MonoBehaviour
{
    public void Quit()
    {

        Application.Quit();
    }
}
